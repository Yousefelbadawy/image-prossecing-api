image resizing api 

steps to run the file 

1- sudo run build
2- sudo run start 

the server port is 8000