import express from 'express';
import * as fs from 'fs';
const sharp =require('sharp')
const app = express();

const port = process.env.PORT || 8000;
app.listen(port, () => {
  console.log(`server running on port:${port} `);
});

const resize = async (req: any, res: any, next: () => void) => {
   sharp(`./inimg/1.jpg`).resize(200, 200).toFile('outimg.jpg');
  next();
};

const sendBack = async (req: any, res: { end: (arg0: Buffer) => void; }, next: () => void) => {
   fs.readFile('outimg.jpg', function (err, data) {
    if (err) console.log('oops'); // Fail if the file can't be read.
    res.end(data); // Send the file data to the browser.
  });
  next();
};


app.get('/', (req: any, res: { send: (arg0: string) => void; }) => {
  res.send('wokring');
});

app.get('/api/images', resize, sendBack, (req: any, res: any) => {});
